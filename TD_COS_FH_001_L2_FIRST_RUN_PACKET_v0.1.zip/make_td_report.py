#!/usr/bin/env python3
"""Render the human-readable TD-COS-FH-001 pre-production run receipt."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


PRESERVED_COMPANION = {
    "accepted_nonidentity": 1_108_720,
    "nonidentity_proposals": 6_046_883,
    "sector_counts": {
        "000": 10341,
        "001": 10120,
        "010": 10105,
        "011": 9877,
        "100": 10055,
        "101": 9763,
        "110": 10008,
        "111": 9731,
    },
    "raw_roundtrips": {"x": 16775, "y": 16950, "z": 16766},
    "largest_classical_split_Rhat": 1.0002210,
    "winding_range": [-6, 6],
    "maximum_absolute_link_current": 6,
}


def pct(value: float, digits: int = 4) -> str:
    return f"{100.0 * value:.{digits}f}%"


def render(receipt: dict[str, object], verification: dict[str, object]) -> str:
    agg = receipt["aggregate"]
    coverage = agg["coverage"]
    mixing = agg["mixing_evidence"]
    axes = mixing["axis_indicators"]
    outcomes = agg["outcomes"]
    nonidentity = agg["attempted_microticks"] - outcomes["IDENTITY"]
    accepted_delta = outcomes["ACCEPTED"] - PRESERVED_COMPANION["accepted_nonidentity"]
    largest_classical = max(
        [axes[a]["classical_split_Rhat"] for a in ("x", "y", "z")]
        + [mixing["membrane_occupancy"]["classical_split_Rhat"]]
    )

    lines: list[str] = []
    lines.extend(
        [
            "# TD-COS-FH-001 — L=2 Frozen-Prose Execution Receipt v0.1",
            "",
            "**Run:** `TD-COS-FH-001-L2-REPRODUCTION-001`  ",
            "**Disposition:** invariants PASS; eight-sector coverage PASS; mixing evidence favorable but incomplete; production **NOT AUTHORIZED**; physical Q2 **NOT RUN**.",
            "",
            "## Bottom line",
            "",
            (
                f"The declared eight-chain engineering profile completed all {agg['attempted_microticks']:,} microticks "
                f"and retained {agg['retained_measurements']:,} sweep-end measurements. The sampler recorded "
                f"{outcomes['ACCEPTED']:,} accepted nonidentity updates, {outcomes['REJECTED']:,} rejected "
                f"nonidentity proposals, and {outcomes['IDENTITY']:,} identity updates. No invariant failure occurred."
            ),
            "",
            (
                "Every chain visited all eight q sectors after warmup, both at event level and at retained-sweep "
                "resolution. Rank-normalized split R-hat stayed near one and bulk ESS was far above 1,000 on each "
                "axis. Those facts are evidence of movement and cross-chain agreement at L=2; they do not validate "
                "warmup, establish effective round trips, substitute for the separately labelled all-zero-start "
                "control, or authorize larger-lattice production."
            ),
            "",
            "## Provenance decision",
            "",
            (
                "The Google Doc named `DYNAMICS.json` as machine-readable authority, but the native document contains "
                "only the literal unlinked relative-path text and Drive contains no retrievable file with that name. "
                "Accordingly this execution is labeled **FROZEN_PROSE_PROFILE_WITH_UNRECOVERED_MACHINE_AUTHORITY**. "
                "It is not represented as a bit-exact execution of an unavailable file."
            ),
            "",
            (
                "A later same-day document, `Tiny-system validation v0.1`, already records a run. This receipt is an "
                "independent prose-conformant execution, not a claim to be the first historical run and not a rewrite "
                "of either source document."
            ),
            "",
            "## Frozen profile executed",
            "",
            "| Item | Executed value |",
            "|---|---|",
            "| Kernel | TD-COS-FH-001, cosine weights, fixed-reference Z000 |",
            "| Couplings | J=1, t=1/2, h6=0 |",
            "| Geometry | 2×2×2 periodic torus; V=8, E=24, P=24 |",
            "| State | signed integer edge current I; binary face membrane M; three-bit q |",
            "| Proposal weights | (8, 8, 24, 24, 1, 3, 3); B=71 microticks/sweep |",
            "| Chains | 8, initialized once each in q=000 through 111 |",
            "| Per chain | 2,000 warmup sweeps + 10,000 retained sweeps |",
            "| Seeds | proposal 64000–64007; acceptance 74000–74007 |",
            "| Observation clock | first retained microtick 142,071; last 852,000 |",
            "| Acceptance | rational I_n(1) enclosures; 64-bit half-open U prefix |",
            "",
            "## Invariant evidence",
            "",
            f"**Status: {agg['invariants']['status']}.** {agg['invariants']['checks_executed']:,} online checks; {agg['invariants']['failures']} failures.",
            "",
            "| Declared invariant or consistency condition | Result |",
            "|---|---|",
            "| Integer-current conservation, div I=0 | PASS |",
            "| I mod 2 + boundary(M) + Gamma(q)=0 | PASS |",
            "| Every transverse cut gives the same signed W per axis | PASS |",
            "| q_alpha = W_alpha mod 2 | PASS |",
            "| Cached N_M equals the binary membrane occupancy | PASS |",
            "| All 123 proposal descriptors preserve the constraints and have tested inverses | PASS |",
            "| Rational Bessel comparison refinement | 0 refinements; K=16 and 64 bits resolved every decision |",
            "",
            "The online checks ran after every accepted nonidentity update and again at retained measurements and checkpoints. The compact sample file independently rechecks retained q/W parity, counts, shapes, digests, and receipt accounting; it does not contain every full I/M state.",
            "",
            "## Coverage",
            "",
            "| q sector | Retained count | Probability | Preserved companion | Difference (percentage points) |",
            "|---:|---:|---:|---:|---:|",
        ]
    )
    for sector in [f"{i:03b}" for i in range(8)]:
        count = coverage["sector_counts"][sector]
        probability = coverage["sector_probabilities"][sector]
        other_count = PRESERVED_COMPANION["sector_counts"][sector]
        other_probability = other_count / 80000
        diff_pp = 100.0 * (probability - other_probability)
        lines.append(
            f"| {sector} | {count:,} | {pct(probability)} | {pct(other_probability)} | {diff_pp:+.4f} |"
        )
    lines.extend(
        [
            "",
            "Every chain covered all eight sectors at event level and at retained sweeps. Positive and negative signed winding occurred on every axis. Observed winding ranges were x=[{x0},{x1}], y=[{y0},{y1}], z=[{z0},{z1}], and max |I_link| was {imax}; these are observations, not cutoffs.".format(
                x0=axes["x"]["winding_observed_min"],
                x1=axes["x"]["winding_observed_max"],
                y0=axes["y"]["winding_observed_min"],
                y1=axes["y"]["winding_observed_max"],
                z0=axes["z"]["winding_observed_min"],
                z1=axes["z"]["winding_observed_max"],
                imax=coverage["maximum_observed_absolute_link_current"],
            ),
            "",
            "## Mixing evidence",
            "",
            "| Observable | Mean / odd fraction | Classical split R-hat | Rank-normalized split R-hat | Rank bulk ESS | Raw 0→1→0 trips |",
            "|---|---:|---:|---:|---:|---:|",
        ]
    )
    for axis in ("x", "y", "z"):
        metric = axes[axis]
        lines.append(
            f"| 1[q_{axis}=1] | {metric['odd_fraction']:.6f} | {metric['classical_split_Rhat']:.7f} | "
            f"{metric['rank_normalized_split_Rhat']['max']:.7f} | {metric['rank_bulk_ESS']:.0f} | "
            f"{metric['raw_roundtrips_0_1_0']:,} |"
        )
    membrane = mixing["membrane_occupancy"]
    lines.append(
        f"| N_M | — | {membrane['classical_split_Rhat']:.7f} | "
        f"{membrane['rank_normalized_split_Rhat']['max']:.7f} | {membrane['rank_bulk_ESS']:.0f} | — |"
    )
    lines.extend(
        [
            "",
            f"Largest classical split R-hat: **{largest_classical:.7f}**. Retained-sweep q residence runs had median 1 sweep, 95th percentile {mixing['retained_sweep_sector_residence']['p95']:.0f}, and maximum {mixing['retained_sweep_sector_residence']['maximum']} sweeps.",
            "",
            "The numerical pieces of the inherited screen are favorable: rank-normalized R-hat is below 1.01 and rank bulk ESS exceeds 1,000 on every axis. The full mixing gate is **not established** because the counted trips are raw, not decorrelated/effective, and the separately labelled all-zero-start control was not part of this fixed profile.",
            "",
            "### Retained-sweep q transition counts",
            "",
            "Rows are the current sector; columns are the next retained-sweep sector.",
            "",
            "| from \\ to | 000 | 001 | 010 | 011 | 100 | 101 | 110 | 111 |",
            "|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
        ]
    )
    matrix = mixing["retained_sweep_q_transition_counts"]
    for i, row in enumerate(matrix):
        lines.append(f"| {i:03b} | " + " | ".join(f"{value:,}" for value in row) + " |")

    lines.extend(
        [
            "",
            "## Proposal and acceptance coverage",
            "",
            "| Family | Attempts | Accepted | Acceptance fraction |",
            "|---|---:|---:|---:|",
        ]
    )
    family_order = [
        "IDENTITY",
        "CUBE",
        "COUPLED_PLAQUETTE",
        "EVEN_PLAQUETTE",
        "CLOSED_SHEET",
        "EVEN_REFERENCE_CYCLE",
        "UNIT_SECTOR_CYCLE",
    ]
    for family in family_order:
        values = agg["family_stats"][family]
        frac = "—" if values["acceptance_fraction"] is None else pct(values["acceptance_fraction"], 3)
        lines.append(
            f"| {family} | {values['attempted']:,} | {values['accepted_nonidentity']:,} | {frac} |"
        )

    max_sector_diff = max(
        abs(
            100.0
            * (
                coverage["sector_probabilities"][sector]
                - PRESERVED_COMPANION["sector_counts"][sector] / 80000
            )
        )
        for sector in PRESERVED_COMPANION["sector_counts"]
    )
    lines.extend(
        [
            "",
            "## Comparison with the later Drive companion",
            "",
            f"The proposal accounting agrees exactly: both records contain **{nonidentity:,} nonidentity proposals**. The trajectories do not agree bit-for-bit: this run accepted {outcomes['ACCEPTED']:,}, versus {PRESERVED_COMPANION['accepted_nonidentity']:,} in the companion ({accepted_delta:+,}); raw round-trip differences are x={axes['x']['raw_roundtrips_0_1_0']-PRESERVED_COMPANION['raw_roundtrips']['x']:+,}, y={axes['y']['raw_roundtrips_0_1_0']-PRESERVED_COMPANION['raw_roundtrips']['y']:+,}, z={axes['z']['raw_roundtrips_0_1_0']-PRESERVED_COMPANION['raw_roundtrips']['z']:+,}. The largest sector-probability point difference is {max_sector_diff:.4f} percentage points.",
            "",
            "That pattern is consistent with the same proposal schedule but a different unrecovered low-level convention such as cell indexing/orientation or acceptance implementation. It is not enough to identify which convention differs. Because the named machine-readable authority is absent, this receipt preserves the mismatch instead of harmonizing it away.",
            "",
            "## Decision",
            "",
            "- Accept this packet as an executable, reproducible L=2 **pre-production engineering run** of the frozen prose profile.",
            "- Accept the declared invariant and eight-sector coverage evidence for this implementation.",
            "- Treat the mixing results as favorable diagnostics, not production certification.",
            "- Do not infer confinement, deconfinement, equilibrium at larger L, a physical timescale, or physical Q2.",
            "- Before any production authorization, recover or formally replace the missing authoritative `DYNAMICS.json`, resolve the deterministic mismatch, run the separately labelled all-zero-start control, establish effective—not merely raw—round trips, and execute the larger-lattice validation gates under a new frozen profile.",
            "",
            "## Verification",
            "",
            f"Independent receipt verification: **{verification['status']}** ({sum(verification['checks'].values())}/{len(verification['checks'])} checks passed).",
            "",
            "CC0 1.0 Universal. No production authorization. No physical Q2 result.",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", required=True)
    parser.add_argument("--verification", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    receipt = json.loads(Path(args.results).read_text(encoding="utf-8"))
    verification = json.loads(Path(args.verification).read_text(encoding="utf-8"))
    report = render(receipt, verification)
    Path(args.output).write_text(report, encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
