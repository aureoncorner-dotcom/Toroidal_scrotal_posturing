#!/usr/bin/env python3
"""Executable reference sampler for the frozen TD-COS-FH-001 kernel.

The implementation follows the 6 September 2026 ``Toroidal Dynamics v0.1``
definition.  It intentionally reports engineering evidence and never emits a
production or physical-Q2 authorization.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import math
import os
import platform
import random
import struct
import sys
import time
from collections import Counter, defaultdict
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
from scipy.stats import norm, rankdata


AXIS_NAMES = ("x", "y", "z")
FACE_AXES = ((0, 1), (0, 2), (1, 2))
FAMILY_NAMES = (
    "IDENTITY",
    "CUBE",
    "COUPLED_PLAQUETTE",
    "EVEN_PLAQUETTE",
    "CLOSED_SHEET",
    "EVEN_REFERENCE_CYCLE",
    "UNIT_SECTOR_CYCLE",
)
OUTCOME_IDENTITY = 0
OUTCOME_ACCEPTED = 1
OUTCOME_REJECTED = 2


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def canonical_json_bytes(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")


def randbelow_bits(rng: random.Random, n: int) -> int:
    """Uniform integer in [0,n), using getrandbits and bit rejection only."""
    if n < 1:
        raise ValueError("n must be positive")
    if n == 1:
        return 0
    width = (n - 1).bit_length()
    while True:
        candidate = rng.getrandbits(width)
        if candidate < n:
            return candidate


def sign_bit(rng: random.Random) -> int:
    return 1 if rng.getrandbits(1) else -1


@dataclass(frozen=True)
class Geometry:
    shape: tuple[int, int, int]
    vertices: tuple[tuple[int, int, int], ...]
    edges: tuple[tuple[tuple[int, int, int], int], ...]
    faces: tuple[tuple[tuple[int, int, int], tuple[int, int]], ...]
    cubes: tuple[tuple[int, int, int], ...]
    edge_index: dict[tuple[tuple[int, int, int], int], int]
    face_index: dict[tuple[tuple[int, int, int], tuple[int, int]], int]
    face_boundaries: tuple[tuple[tuple[int, int], ...], ...]
    cube_faces: tuple[tuple[int, ...], ...]
    sheets: tuple[tuple[tuple[int, ...], ...], ...]
    cycles: tuple[tuple[int, ...], ...]
    cut_edges: tuple[tuple[tuple[int, ...], ...], ...]

    @property
    def V(self) -> int:
        return len(self.vertices)

    @property
    def E(self) -> int:
        return len(self.edges)

    @property
    def P(self) -> int:
        return len(self.faces)

    @property
    def B(self) -> int:
        return 8 * self.V + 7


def add_axis(base: tuple[int, int, int], axis: int, shape: Sequence[int]) -> tuple[int, int, int]:
    out = list(base)
    out[axis] = (out[axis] + 1) % shape[axis]
    return tuple(out)  # type: ignore[return-value]


def make_geometry(shape: tuple[int, int, int] = (2, 2, 2)) -> Geometry:
    if any(L < 2 for L in shape):
        raise ValueError("every side length must be at least two")
    vertices = tuple(
        (x, y, z)
        for x in range(shape[0])
        for y in range(shape[1])
        for z in range(shape[2])
    )
    edges = tuple((base, axis) for base in vertices for axis in range(3))
    faces = tuple((base, axes) for base in vertices for axes in FACE_AXES)
    cubes = vertices
    edge_index = {edge: i for i, edge in enumerate(edges)}
    face_index = {face: i for i, face in enumerate(faces)}

    boundaries: list[tuple[tuple[int, int], ...]] = []
    for base, (a, b) in faces:
        base_a = add_axis(base, a, shape)
        base_b = add_axis(base, b, shape)
        boundaries.append(
            (
                (edge_index[(base, a)], +1),
                (edge_index[(base_a, b)], +1),
                (edge_index[(base_b, a)], -1),
                (edge_index[(base, b)], -1),
            )
        )

    cube_faces: list[tuple[int, ...]] = []
    for base in cubes:
        ids: list[int] = []
        for normal in range(3):
            tangential = tuple(a for a in range(3) if a != normal)
            ids.append(face_index[(base, tangential)])
            ids.append(face_index[(add_axis(base, normal, shape), tangential)])
        cube_faces.append(tuple(ids))

    sheets: list[tuple[tuple[int, ...], ...]] = []
    for normal in range(3):
        tangential = tuple(a for a in range(3) if a != normal)
        axis_sheets: list[tuple[int, ...]] = []
        for cut in range(shape[normal]):
            axis_sheets.append(
                tuple(
                    face_index[(base, tangential)]
                    for base in vertices
                    if base[normal] == cut
                )
            )
        sheets.append(tuple(axis_sheets))

    cycles: list[tuple[int, ...]] = []
    origin = (0, 0, 0)
    for axis in range(3):
        base = origin
        ids: list[int] = []
        for _ in range(shape[axis]):
            ids.append(edge_index[(base, axis)])
            base = add_axis(base, axis, shape)
        cycles.append(tuple(ids))

    cut_edges: list[tuple[tuple[int, ...], ...]] = []
    for axis in range(3):
        cuts: list[tuple[int, ...]] = []
        for cut in range(shape[axis]):
            cuts.append(
                tuple(
                    edge_index[(base, axis)]
                    for base in vertices
                    if base[axis] == cut
                )
            )
        cut_edges.append(tuple(cuts))

    return Geometry(
        shape=shape,
        vertices=vertices,
        edges=edges,
        faces=faces,
        cubes=cubes,
        edge_index=edge_index,
        face_index=face_index,
        face_boundaries=tuple(boundaries),
        cube_faces=tuple(cube_faces),
        sheets=tuple(sheets),
        cycles=tuple(cycles),
        cut_edges=tuple(cut_edges),
    )


def bessel_interval(n: int, order: int) -> tuple[Fraction, Fraction]:
    """Positive rational enclosure for I_n(1), summing k=0..order."""
    if n < 0 or order < 0:
        raise ValueError("n and order must be nonnegative")
    term = Fraction(1, (1 << n) * math.factorial(n))
    total = term
    for k in range(1, order + 1):
        term /= 4 * k * (n + k)
        total += term
    rho = Fraction(1, 4 * (order + 1) * (n + order + 1))
    upper = total + term * rho / (1 - rho)
    return total, upper


class AcceptanceOracle:
    """Cache exact interval-derived prefix thresholds by weight signature."""

    def __init__(self) -> None:
        self._bessel: dict[tuple[int, int], tuple[Fraction, Fraction]] = {}
        self._bounds: dict[tuple[tuple[int, tuple[tuple[int, int], ...]], int], tuple[Fraction, Fraction]] = {}
        self._thresholds: dict[
            tuple[tuple[int, tuple[tuple[int, int], ...]], int, int], tuple[bool, int, int]
        ] = {}
        self.signature_uses: Counter[str] = Counter()
        self.refinements = 0
        self.max_order = 16
        self.max_prefix_bits = 0

    def interval(self, n: int, order: int) -> tuple[Fraction, Fraction]:
        key = (n, order)
        if key not in self._bessel:
            self._bessel[key] = bessel_interval(n, order)
        return self._bessel[key]

    def ratio_bounds(
        self,
        signature: tuple[int, tuple[tuple[int, int], ...]],
        order: int,
    ) -> tuple[Fraction, Fraction]:
        key = (signature, order)
        if key in self._bounds:
            return self._bounds[key]
        delta_nm, powers = signature
        if delta_nm >= 0:
            low = high = Fraction(1, 1 << delta_nm)
        else:
            low = high = Fraction(1 << (-delta_nm), 1)
        for n, exponent in powers:
            lo_n, hi_n = self.interval(n, order)
            if exponent > 0:
                low *= lo_n**exponent
                high *= hi_n**exponent
            else:
                count = -exponent
                low /= hi_n**count
                high /= lo_n**count
        self._bounds[key] = (low, high)
        return low, high

    @staticmethod
    def _floor_scaled(value: Fraction, bits: int) -> int:
        return (value.numerator << bits) // value.denominator

    @staticmethod
    def _ceil_scaled(value: Fraction, bits: int) -> int:
        num = value.numerator << bits
        return (num + value.denominator - 1) // value.denominator

    def thresholds(
        self,
        signature: tuple[int, tuple[tuple[int, int], ...]],
        order: int,
        bits: int,
    ) -> tuple[bool, int, int]:
        key = (signature, order, bits)
        if key in self._thresholds:
            return self._thresholds[key]
        low, high = self.ratio_bounds(signature, order)
        if low >= 1:
            result = (True, 1 << bits, 1 << bits)
        else:
            upper_a = min(Fraction(1), high)
            result = (
                False,
                self._floor_scaled(low, bits),
                self._ceil_scaled(upper_a, bits),
            )
        self._thresholds[key] = result
        return result

    def decide(
        self,
        signature: tuple[int, tuple[tuple[int, int], ...]],
        rng: random.Random,
    ) -> tuple[bool, int, int, int]:
        """Return accepted, prefix, prefix_bits, final series order."""
        delta_nm, powers = signature
        if delta_nm == 0 and not powers:
            self.signature_uses["unit"] += 1
            return True, 0, 0, 16
        signature_label = f"{delta_nm}|{powers}"
        self.signature_uses[signature_label] += 1
        order = 16
        bits = 64
        accept_one, accept_below, reject_at = self.thresholds(signature, order, bits)
        if accept_one:
            return True, 0, 0, order
        prefix = rng.getrandbits(64)
        self.max_prefix_bits = max(self.max_prefix_bits, bits)
        while True:
            if prefix < accept_below:
                return True, prefix, bits, order
            if prefix >= reject_at:
                return False, prefix, bits, order
            self.refinements += 1
            order += 16
            next_bits = rng.getrandbits(64)
            prefix = (prefix << 64) | next_bits
            bits += 64
            self.max_order = max(self.max_order, order)
            self.max_prefix_bits = max(self.max_prefix_bits, bits)
            accept_one, accept_below, reject_at = self.thresholds(signature, order, bits)
            if accept_one:
                return True, prefix, bits, order


@dataclass
class State:
    I: list[int]
    M: bytearray
    q: int
    nm: int


def initial_state(geometry: Geometry, q: int) -> State:
    currents = [0] * geometry.E
    for axis in range(3):
        if (q >> axis) & 1:
            for edge in geometry.cycles[axis]:
                currents[edge] += 1
    return State(I=currents, M=bytearray(geometry.P), q=q, nm=0)


def winding_cuts(state: State, geometry: Geometry) -> tuple[tuple[int, ...], ...]:
    return tuple(
        tuple(sum(state.I[e] for e in cut) for cut in geometry.cut_edges[axis])
        for axis in range(3)
    )


def signed_winding(state: State, geometry: Geometry) -> tuple[int, int, int]:
    cuts = winding_cuts(state, geometry)
    return tuple(axis_cuts[0] for axis_cuts in cuts)  # type: ignore[return-value]


def validate_state(state: State, geometry: Geometry) -> tuple[int, int, int]:
    divergence = [0] * geometry.V
    vertex_index = {v: i for i, v in enumerate(geometry.vertices)}
    for edge_id, (base, axis) in enumerate(geometry.edges):
        head = add_axis(base, axis, geometry.shape)
        value = state.I[edge_id]
        divergence[vertex_index[base]] += value
        divergence[vertex_index[head]] -= value
    if any(divergence):
        raise AssertionError(f"integer-current conservation failed: {divergence}")

    membrane_boundary = [0] * geometry.E
    for face_id, bit in enumerate(state.M):
        if bit:
            for edge_id, _ in geometry.face_boundaries[face_id]:
                membrane_boundary[edge_id] ^= 1
    gamma = [0] * geometry.E
    for axis in range(3):
        if (state.q >> axis) & 1:
            for edge_id in geometry.cycles[axis]:
                gamma[edge_id] ^= 1
    parity_residual = [
        (state.I[e] & 1) ^ membrane_boundary[e] ^ gamma[e]
        for e in range(geometry.E)
    ]
    if any(parity_residual):
        raise AssertionError("mod-two membrane constraint failed")

    cuts = winding_cuts(state, geometry)
    for axis, axis_cuts in enumerate(cuts):
        if len(set(axis_cuts)) != 1:
            raise AssertionError(f"cut winding mismatch on axis {axis}: {axis_cuts}")
    winding = tuple(axis_cuts[0] for axis_cuts in cuts)
    for axis, value in enumerate(winding):
        if (value & 1) != ((state.q >> axis) & 1):
            raise AssertionError(f"q/winding parity mismatch on axis {axis}")
    if state.nm != sum(state.M):
        raise AssertionError("cached membrane occupancy mismatch")
    return winding  # type: ignore[return-value]


def state_bytes(state: State) -> bytes:
    return struct.pack(
        f"<I{len(state.I)}q{len(state.M)}sB",
        len(state.I),
        *state.I,
        bytes(state.M),
        state.q,
    )


def state_hash(state: State) -> bytes:
    return hashlib.blake2b(state_bytes(state), digest_size=16).digest()


def rng_state_digest(rng: random.Random) -> str:
    return hashlib.sha256(repr(rng.getstate()).encode("ascii")).hexdigest()


def ratio_signature(
    state: State,
    current_changes: Sequence[tuple[int, int]],
    delta_nm: int,
) -> tuple[int, tuple[tuple[int, int], ...]]:
    power: Counter[int] = Counter()
    combined: defaultdict[int, int] = defaultdict(int)
    for edge, delta in current_changes:
        combined[edge] += delta
    for edge, delta in combined.items():
        if not delta:
            continue
        before = abs(state.I[edge])
        after = abs(state.I[edge] + delta)
        power[after] += 1
        power[before] -= 1
    return delta_nm, tuple(sorted((n, c) for n, c in power.items() if c))


def split_chains(values: np.ndarray) -> np.ndarray:
    if values.ndim != 2:
        raise ValueError("values must be chains x draws")
    n = values.shape[1]
    half = n // 2
    if half < 2:
        raise ValueError("too few draws")
    return np.concatenate((values[:, :half], values[:, n - half :]), axis=0)


def basic_rhat(values: np.ndarray) -> float:
    values = np.asarray(values, dtype=float)
    m, n = values.shape
    chain_var = np.var(values, axis=1, ddof=1)
    W = float(np.mean(chain_var))
    B = float(n * np.var(np.mean(values, axis=1), ddof=1))
    if W == 0:
        return 1.0 if B == 0 else math.inf
    var_plus = (n - 1) / n * W + B / n
    return math.sqrt(max(var_plus / W, 0.0))


def rank_normalize(values: np.ndarray) -> np.ndarray:
    flat = np.asarray(values, dtype=float).ravel()
    ranks = rankdata(flat, method="average")
    transformed = norm.ppf((ranks - 3.0 / 8.0) / (len(flat) + 1.0 / 4.0))
    return transformed.reshape(values.shape)


def rank_normalized_split_rhat(values: np.ndarray) -> dict[str, float]:
    split = split_chains(values)
    ranked = rank_normalize(split)
    folded_source = np.abs(split - np.median(split))
    folded_ranked = rank_normalize(folded_source)
    rank_rhat = basic_rhat(ranked)
    folded_rhat = basic_rhat(folded_ranked)
    return {
        "rank": rank_rhat,
        "folded": folded_rhat,
        "max": max(rank_rhat, folded_rhat),
    }


def autocovariance_fft(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    n = x.size
    centered = x - np.mean(x)
    size = 1 << (2 * n - 1).bit_length()
    spectrum = np.fft.rfft(centered, n=size)
    acov = np.fft.irfft(spectrum * np.conjugate(spectrum), n=size)[:n]
    return acov / n


def geyer_ess(values: np.ndarray) -> float:
    """Multi-chain ESS with Geyer's initial positive/monotone sequence."""
    x = np.asarray(values, dtype=float)
    m, n = x.shape
    if np.all(x == x.flat[0]):
        return float(m * n)
    acov = np.vstack([autocovariance_fft(row) for row in x])
    chain_var = np.var(x, axis=1, ddof=1)
    W = float(np.mean(chain_var))
    B = float(n * np.var(np.mean(x, axis=1), ddof=1))
    var_plus = (n - 1) / n * W + B / n
    if not math.isfinite(var_plus) or var_plus <= 0:
        return float("nan")
    rho = np.empty(n, dtype=float)
    rho[0] = 1.0
    mean_acov = np.mean(acov, axis=0)
    rho[1:] = 1.0 - (W - mean_acov[1:]) / var_plus
    pairs: list[float] = []
    for k in range(0, n - 1, 2):
        pair = float(rho[k] + rho[k + 1])
        if pair < 0:
            break
        if pairs and pair > pairs[-1]:
            pair = pairs[-1]
        pairs.append(pair)
    tau = -1.0 + 2.0 * sum(pairs)
    tau = max(tau, 1.0 / math.log10(max(m * n, 10)))
    return min(float(m * n), float(m * n / tau))


def rank_bulk_ess(values: np.ndarray) -> float:
    return geyer_ess(rank_normalize(split_chains(values)))


def summarize_residences(q_samples: np.ndarray) -> dict[str, object]:
    lengths: list[int] = []
    by_sector: dict[int, list[int]] = {q: [] for q in range(8)}
    for chain in q_samples:
        start = 0
        for j in range(1, len(chain) + 1):
            if j == len(chain) or chain[j] != chain[start]:
                length = j - start
                q = int(chain[start])
                lengths.append(length)
                by_sector[q].append(length)
                start = j
    arr = np.asarray(lengths, dtype=float)
    return {
        "units": "retained_sweeps",
        "run_count": len(lengths),
        "mean": float(np.mean(arr)),
        "median": float(np.median(arr)),
        "p95": float(np.quantile(arr, 0.95)),
        "maximum": int(np.max(arr)),
        "by_sector": {
            f"{q:03b}": {
                "runs": len(vals),
                "mean": float(np.mean(vals)) if vals else None,
                "maximum": max(vals) if vals else None,
            }
            for q, vals in by_sector.items()
        },
    }


class ChainRunner:
    def __init__(
        self,
        chain: int,
        geometry: Geometry,
        warmup_sweeps: int,
        retained_sweeps: int,
        checkpoint_every: int,
        invariant_mode: str,
    ) -> None:
        self.chain = chain
        self.g = geometry
        self.warmup_sweeps = warmup_sweeps
        self.retained_sweeps = retained_sweeps
        self.checkpoint_every = checkpoint_every
        self.invariant_mode = invariant_mode
        self.proposal_seed = 64000 + chain
        self.acceptance_seed = 74000 + chain
        self.proposal_rng = random.Random(self.proposal_seed)
        self.acceptance_rng = random.Random(self.acceptance_seed)
        self.state = initial_state(geometry, chain)
        self.oracle = AcceptanceOracle()
        self.family_attempts = Counter()
        self.family_accepted = Counter()
        self.outcomes = Counter()
        self.acceptance_bits = Counter()
        self.invariant_checks = 0
        self.invariant_failures = 0
        self.event_digest = hashlib.sha256()
        self.measurement_digest = hashlib.sha256()
        self.current_state_hash = state_hash(self.state)
        self.current_winding = signed_winding(self.state, self.g)
        self.checkpoints: list[dict[str, object]] = []
        self.event_sector_seen: set[int] = set()
        self.retained_sector_seen: set[int] = set()
        self.winding_min = [10**9] * 3
        self.winding_max = [-10**9] * 3
        self.max_abs_current = 0
        self.roundtrips = [0, 0, 0]
        self.roundtrip_phase = [0, 0, 0]
        self.after_warmup = False

    def choose_family(self) -> int:
        r = randbelow_bits(self.proposal_rng, self.g.B)
        boundaries = (
            self.g.V,
            2 * self.g.V,
            5 * self.g.V,
            8 * self.g.V,
            8 * self.g.V + 1,
            8 * self.g.V + 4,
            8 * self.g.V + 7,
        )
        for family, boundary in enumerate(boundaries):
            if r < boundary:
                return family
        raise AssertionError("family selection escaped normalization")

    def proposal(self, family: int) -> tuple[int, int, int, list[tuple[int, int]], tuple[int, ...], int]:
        """Return descriptor_a, descriptor_b, sign, I changes, M toggles, q xor."""
        if family == 0:
            return -1, -1, 0, [], (), 0
        if family == 1:
            cube = randbelow_bits(self.proposal_rng, self.g.V)
            return cube, -1, 0, [], self.g.cube_faces[cube], 0
        if family in (2, 3):
            face = randbelow_bits(self.proposal_rng, self.g.P)
            s = sign_bit(self.proposal_rng)
            multiplier = 1 if family == 2 else 2
            changes = [(edge, multiplier * s * coeff) for edge, coeff in self.g.face_boundaries[face]]
            toggles = (face,) if family == 2 else ()
            return face, -1, s, changes, toggles, 0
        if family == 4:
            axis = randbelow_bits(self.proposal_rng, 3)
            cut = randbelow_bits(self.proposal_rng, self.g.shape[axis])
            return axis, cut, 0, [], self.g.sheets[axis][cut], 0
        if family in (5, 6):
            axis = randbelow_bits(self.proposal_rng, 3)
            s = sign_bit(self.proposal_rng)
            multiplier = 2 if family == 5 else 1
            changes = [(edge, multiplier * s) for edge in self.g.cycles[axis]]
            q_xor = (1 << axis) if family == 6 else 0
            return axis, -1, s, changes, (), q_xor
        raise AssertionError("unknown family")

    def _track_roundtrips(self, before_q: int, after_q: int) -> None:
        if not self.after_warmup or before_q == after_q:
            return
        for axis in range(3):
            before = (before_q >> axis) & 1
            after = (after_q >> axis) & 1
            if before == after:
                continue
            if before == 0 and after == 1:
                self.roundtrip_phase[axis] = 1
            elif before == 1 and after == 0:
                if self.roundtrip_phase[axis] == 1:
                    self.roundtrips[axis] += 1
                self.roundtrip_phase[axis] = 0

    def _update_extrema(self, winding: tuple[int, int, int]) -> None:
        for axis, value in enumerate(winding):
            self.winding_min[axis] = min(self.winding_min[axis], value)
            self.winding_max[axis] = max(self.winding_max[axis], value)
        self.max_abs_current = max(self.max_abs_current, *(abs(v) for v in self.state.I))

    def microtick(self, microtick: int) -> None:
        family = self.choose_family()
        family_name = FAMILY_NAMES[family]
        self.family_attempts[family_name] += 1
        before_q = self.state.q
        before_w = self.current_winding
        before_hash = self.current_state_hash
        desc_a, desc_b, s, changes, toggles, q_xor = self.proposal(family)
        prefix = 0
        prefix_bits = 0
        final_order = 16

        if family == 0:
            outcome = OUTCOME_IDENTITY
            self.outcomes["IDENTITY"] += 1
            after_w = before_w
        else:
            delta_nm = sum(1 - 2 * self.state.M[face] for face in toggles)
            signature = ratio_signature(self.state, changes, delta_nm)
            accepted, prefix, prefix_bits, final_order = self.oracle.decide(signature, self.acceptance_rng)
            self.acceptance_bits[str(prefix_bits)] += 1
            if accepted:
                for face in toggles:
                    self.state.M[face] ^= 1
                self.state.nm += delta_nm
                for edge, delta in changes:
                    self.state.I[edge] += delta
                self.state.q ^= q_xor
                outcome = OUTCOME_ACCEPTED
                self.outcomes["ACCEPTED"] += 1
                self.family_accepted[family_name] += 1
                try:
                    if self.invariant_mode == "accepted":
                        after_w = validate_state(self.state, self.g)
                        self.invariant_checks += 1
                    else:
                        after_w = signed_winding(self.state, self.g)
                except Exception:
                    self.invariant_failures += 1
                    raise
                self._track_roundtrips(before_q, self.state.q)
                self._update_extrema(after_w)
                self.current_winding = after_w
                self.current_state_hash = state_hash(self.state)
            else:
                outcome = OUTCOME_REJECTED
                self.outcomes["REJECTED"] += 1
                after_w = before_w

        after_hash = self.current_state_hash
        delta_w = tuple(after_w[a] - before_w[a] for a in range(3))
        eta = sum(((delta_w[a] & 1) << a) for a in range(3))
        self.event_digest.update(
            struct.pack(
                "<QBBBBbbH3i3i3iB",
                microtick,
                family,
                outcome,
                self.state.q,
                prefix_bits,
                desc_a,
                desc_b,
                final_order,
                *before_w,
                *after_w,
                *delta_w,
                eta,
            )
        )
        self.event_digest.update(struct.pack("<q", s))
        if prefix_bits:
            self.event_digest.update(prefix.to_bytes(prefix_bits // 8, "big"))
        self.event_digest.update(before_hash)
        self.event_digest.update(after_hash)
        if self.after_warmup:
            self.event_sector_seen.add(self.state.q)

    def checkpoint(self, sweep: int, microtick: int, kind: str) -> None:
        winding = validate_state(self.state, self.g)
        self.invariant_checks += 1
        self.checkpoints.append(
            {
                "kind": kind,
                "sweep": sweep,
                "microtick": microtick,
                "state_hash_blake2b_128": state_hash(self.state).hex(),
                "q": f"{self.state.q:03b}",
                "winding": list(winding),
                "N_M": self.state.nm,
                "sum_I2": sum(v * v for v in self.state.I),
                "proposal_rng_state_sha256": rng_state_digest(self.proposal_rng),
                "acceptance_rng_state_sha256": rng_state_digest(self.acceptance_rng),
            }
        )

    def run(self) -> tuple[dict[str, object], dict[str, np.ndarray]]:
        validate_state(self.state, self.g)
        initial_hash = state_hash(self.state).hex()
        total_sweeps = self.warmup_sweeps + self.retained_sweeps
        q_samples = np.empty(self.retained_sweeps, dtype=np.uint8)
        winding_samples = np.empty((self.retained_sweeps, 3), dtype=np.int32)
        nm_samples = np.empty(self.retained_sweeps, dtype=np.int16)
        sum_i2_samples = np.empty(self.retained_sweeps, dtype=np.int32)
        hash_samples = np.empty((self.retained_sweeps, 16), dtype=np.uint8)

        for sweep in range(1, total_sweeps + 1):
            for _ in range(self.g.B):
                microtick = (sweep - 1) * self.g.B + _ + 1
                self.microtick(microtick)
            if sweep == self.warmup_sweeps:
                self.after_warmup = True
                self.event_sector_seen.add(self.state.q)
                current_w = validate_state(self.state, self.g)
                self.invariant_checks += 1
                self._update_extrema(current_w)
                self.checkpoint(sweep, sweep * self.g.B, "warmup_endpoint")
            if sweep > self.warmup_sweeps:
                k = sweep - self.warmup_sweeps - 1
                current_w = validate_state(self.state, self.g)
                self.invariant_checks += 1
                q_samples[k] = self.state.q
                winding_samples[k, :] = current_w
                nm_samples[k] = self.state.nm
                sum_i2_samples[k] = sum(v * v for v in self.state.I)
                digest = state_hash(self.state)
                hash_samples[k, :] = np.frombuffer(digest, dtype=np.uint8)
                self.measurement_digest.update(digest)
                self.retained_sector_seen.add(self.state.q)
                self._update_extrema(current_w)
                if self.checkpoint_every and (k + 1) % self.checkpoint_every == 0:
                    self.checkpoint(sweep, sweep * self.g.B, "retained_checkpoint")

        family_stats = {}
        for name in FAMILY_NAMES:
            attempted = int(self.family_attempts[name])
            accepted = int(self.family_accepted[name])
            family_stats[name] = {
                "attempted": attempted,
                "accepted_nonidentity": accepted,
                "acceptance_fraction": (accepted / attempted if name != "IDENTITY" and attempted else None),
            }
        retained_counts = np.bincount(q_samples, minlength=8)
        result: dict[str, object] = {
            "chain": self.chain,
            "proposal_seed": self.proposal_seed,
            "acceptance_seed": self.acceptance_seed,
            "initial_q": f"{self.chain:03b}",
            "initial_state_hash_blake2b_128": initial_hash,
            "attempted_microticks": total_sweeps * self.g.B,
            "family_stats": family_stats,
            "outcomes": dict(self.outcomes),
            "acceptance_prefix_bits": dict(self.acceptance_bits),
            "bessel_refinements": self.oracle.refinements,
            "maximum_bessel_order": self.oracle.max_order,
            "maximum_acceptance_prefix_bits": self.oracle.max_prefix_bits,
            "invariant_checks": self.invariant_checks,
            "invariant_failures": self.invariant_failures,
            "event_sector_coverage_after_warmup": [f"{q:03b}" for q in sorted(self.event_sector_seen)],
            "retained_sector_coverage": [f"{q:03b}" for q in sorted(self.retained_sector_seen)],
            "retained_sector_counts": {f"{q:03b}": int(retained_counts[q]) for q in range(8)},
            "raw_parity_roundtrips_0_1_0_after_warmup": dict(zip(AXIS_NAMES, self.roundtrips)),
            "winding_observed_min": dict(zip(AXIS_NAMES, self.winding_min)),
            "winding_observed_max": dict(zip(AXIS_NAMES, self.winding_max)),
            "maximum_observed_absolute_link_current": self.max_abs_current,
            "event_receipt_sha256": self.event_digest.hexdigest(),
            "measurement_state_digest_sha256": self.measurement_digest.hexdigest(),
            "final_state_hash_blake2b_128": state_hash(self.state).hex(),
            "final_proposal_rng_state_sha256": rng_state_digest(self.proposal_rng),
            "final_acceptance_rng_state_sha256": rng_state_digest(self.acceptance_rng),
            "checkpoints": self.checkpoints,
        }
        samples = {
            "q": q_samples,
            "winding": winding_samples,
            "N_M": nm_samples,
            "sum_I2": sum_i2_samples,
            "state_hash_blake2b_128": hash_samples,
        }
        return result, samples


def self_test() -> dict[str, object]:
    g = make_geometry((2, 2, 2))
    assert (g.V, g.E, g.P, len(g.cubes), g.B) == (8, 24, 24, 8, 71)
    assert [len(c) for c in g.cycles] == [2, 2, 2]
    assert all(len(boundary) == 4 for boundary in g.face_boundaries)
    assert all(len(faces) == 6 for faces in g.cube_faces)
    assert all(len(sheet) == 4 for axis in g.sheets for sheet in axis)

    for q in range(8):
        validate_state(initial_state(g, q), g)

    def apply_descriptor(
        state: State,
        changes: Sequence[tuple[int, int]],
        toggles: Sequence[int],
        q_xor: int,
    ) -> State:
        out = State(I=list(state.I), M=bytearray(state.M), q=state.q ^ q_xor, nm=state.nm)
        for face in toggles:
            out.nm += 1 - 2 * out.M[face]
            out.M[face] ^= 1
        for edge, delta in changes:
            out.I[edge] += delta
        return out

    descriptors: list[tuple[list[tuple[int, int]], tuple[int, ...], int]] = [([], (), 0)]
    descriptors.extend(([], faces, 0) for faces in g.cube_faces)
    for face, boundary in enumerate(g.face_boundaries):
        for s in (-1, 1):
            descriptors.append(([(edge, s * coeff) for edge, coeff in boundary], (face,), 0))
    for boundary in g.face_boundaries:
        for s in (-1, 1):
            descriptors.append(([(edge, 2 * s * coeff) for edge, coeff in boundary], (), 0))
    descriptors.extend(([], sheet, 0) for axis in g.sheets for sheet in axis)
    for axis, cycle in enumerate(g.cycles):
        for s in (-1, 1):
            descriptors.append(([(edge, 2 * s) for edge in cycle], (), 0))
    for axis, cycle in enumerate(g.cycles):
        for s in (-1, 1):
            descriptors.append(([(edge, s) for edge in cycle], (), 1 << axis))
    assert len(descriptors) == 123
    for q in range(8):
        base = initial_state(g, q)
        for changes, toggles, q_xor in descriptors:
            moved = apply_descriptor(base, changes, toggles, q_xor)
            validate_state(moved, g)
            inverse = [(edge, -delta) for edge, delta in changes]
            restored = apply_descriptor(moved, inverse, toggles, q_xor)
            assert restored.I == base.I and restored.M == base.M and restored.q == base.q

    # Exact boundary-of-boundary checks over integers and mod two.
    vertex_index = {v: i for i, v in enumerate(g.vertices)}
    for boundary in g.face_boundaries:
        div = [0] * g.V
        for edge, coeff in boundary:
            base, axis = g.edges[edge]
            head = add_axis(base, axis, g.shape)
            div[vertex_index[base]] += coeff
            div[vertex_index[head]] -= coeff
        assert not any(div)
    for faces in g.cube_faces:
        edge_parity = [0] * g.E
        for face in faces:
            for edge, _ in g.face_boundaries[face]:
                edge_parity[edge] ^= 1
        assert not any(edge_parity)
    for axis_sheets in g.sheets:
        for faces in axis_sheets:
            edge_parity = [0] * g.E
            for face in faces:
                for edge, _ in g.face_boundaries[face]:
                    edge_parity[edge] ^= 1
            assert not any(edge_parity)

    # Bessel enclosures agree with SciPy's independent floating implementation.
    from scipy.special import iv

    checked = []
    for n in range(9):
        lo, hi = bessel_interval(n, 16)
        reference = float(iv(n, 1.0))
        # The rational interval is much narrower than a binary64 ulp here, so
        # compare with one outward ulp on each converted endpoint.
        lo_float = math.nextafter(float(lo), -math.inf)
        hi_float = math.nextafter(float(hi), math.inf)
        assert lo_float <= reference <= hi_float
        checked.append(n)

    return {
        "status": "PASS",
        "geometry": {"V": g.V, "E": g.E, "P": g.P, "B": g.B},
        "initial_states_validated": 8,
        "proposal_descriptors_validated_with_inverse": len(descriptors),
        "face_boundary_squared_zero": g.P,
        "cube_boundaries_closed_mod2": len(g.cubes),
        "sheets_closed_mod2": sum(len(axis) for axis in g.sheets),
        "bessel_orders_checked": checked,
    }


def aggregate_results(
    chain_results: list[dict[str, object]],
    sample_sets: list[dict[str, np.ndarray]],
) -> tuple[dict[str, object], dict[str, np.ndarray]]:
    q = np.stack([s["q"] for s in sample_sets], axis=0)
    winding = np.stack([s["winding"] for s in sample_sets], axis=0)
    nm = np.stack([s["N_M"] for s in sample_sets], axis=0)
    sum_i2 = np.stack([s["sum_I2"] for s in sample_sets], axis=0)
    hashes = np.stack([s["state_hash_blake2b_128"] for s in sample_sets], axis=0)

    q_counts = np.bincount(q.ravel(), minlength=8)
    transition = np.zeros((8, 8), dtype=np.int64)
    for chain in q:
        np.add.at(transition, (chain[:-1], chain[1:]), 1)

    family_totals: dict[str, dict[str, object]] = {}
    for family in FAMILY_NAMES:
        attempted = sum(int(c["family_stats"][family]["attempted"]) for c in chain_results)  # type: ignore[index]
        accepted = sum(int(c["family_stats"][family]["accepted_nonidentity"]) for c in chain_results)  # type: ignore[index]
        family_totals[family] = {
            "attempted": attempted,
            "accepted_nonidentity": accepted,
            "acceptance_fraction": accepted / attempted if family != "IDENTITY" and attempted else None,
        }

    outcome_totals = {
        key: sum(int(c["outcomes"].get(key, 0)) for c in chain_results)  # type: ignore[union-attr]
        for key in ("IDENTITY", "ACCEPTED", "REJECTED")
    }
    axis_metrics: dict[str, object] = {}
    for axis, name in enumerate(AXIS_NAMES):
        indicator = ((q >> axis) & 1).astype(float)
        classical = basic_rhat(split_chains(indicator))
        rank_rhat = rank_normalized_split_rhat(indicator)
        ess = rank_bulk_ess(indicator)
        p = float(np.mean(indicator))
        mcse = math.sqrt(p * (1 - p) / ess) if ess > 0 else None
        axis_metrics[name] = {
            "odd_fraction": p,
            "classical_split_Rhat": classical,
            "rank_normalized_split_Rhat": rank_rhat,
            "rank_bulk_ESS": ess,
            "MCSE_from_rank_bulk_ESS": mcse,
            "raw_roundtrips_0_1_0": sum(
                int(c["raw_parity_roundtrips_0_1_0_after_warmup"][name])  # type: ignore[index]
                for c in chain_results
            ),
            "winding_observed_min": min(int(c["winding_observed_min"][name]) for c in chain_results),  # type: ignore[index]
            "winding_observed_max": max(int(c["winding_observed_max"][name]) for c in chain_results),  # type: ignore[index]
        }

    nm_classical = basic_rhat(split_chains(nm.astype(float)))
    nm_rank = rank_normalized_split_rhat(nm.astype(float))
    nm_ess = rank_bulk_ess(nm.astype(float))
    chain_all_event = all(len(c["event_sector_coverage_after_warmup"]) == 8 for c in chain_results)  # type: ignore[arg-type]
    chain_all_retained = all(len(c["retained_sector_coverage"]) == 8 for c in chain_results)  # type: ignore[arg-type]
    invariant_failures = sum(int(c["invariant_failures"]) for c in chain_results)
    aggregate: dict[str, object] = {
        "attempted_microticks": sum(int(c["attempted_microticks"]) for c in chain_results),
        "retained_measurements": int(q.size),
        "family_stats": family_totals,
        "outcomes": outcome_totals,
        "invariants": {
            "status": "PASS" if invariant_failures == 0 else "FAIL",
            "checks_executed": sum(int(c["invariant_checks"]) for c in chain_results),
            "failures": invariant_failures,
            "checked": [
                "integer-current conservation",
                "I mod 2 + boundary(M) + Gamma(q) = 0",
                "all parallel cut windings agree",
                "q = W mod 2",
                "cached N_M equals membrane occupancy",
            ],
        },
        "coverage": {
            "all_8_sectors_observed_in_every_chain_at_event_level_after_warmup": chain_all_event,
            "all_8_sectors_observed_in_every_chain_at_retained_sweeps": chain_all_retained,
            "sector_counts": {f"{sector:03b}": int(q_counts[sector]) for sector in range(8)},
            "sector_probabilities": {f"{sector:03b}": float(q_counts[sector] / q.size) for sector in range(8)},
            "positive_and_negative_winding_observed_every_axis": all(
                axis_metrics[name]["winding_observed_min"] < 0 and axis_metrics[name]["winding_observed_max"] > 0  # type: ignore[index,operator]
                for name in AXIS_NAMES
            ),
            "maximum_observed_absolute_link_current": max(
                int(c["maximum_observed_absolute_link_current"]) for c in chain_results
            ),
        },
        "mixing_evidence": {
            "axis_indicators": axis_metrics,
            "membrane_occupancy": {
                "classical_split_Rhat": nm_classical,
                "rank_normalized_split_Rhat": nm_rank,
                "rank_bulk_ESS": nm_ess,
            },
            "retained_sweep_q_transition_counts": transition.tolist(),
            "retained_sweep_sector_residence": summarize_residences(q),
            "interpretation": (
                "diagnostic evidence only; raw round trips are not effective round trips, "
                "and no separately labelled all-zero-start control was run"
            ),
        },
        "numerical_acceptance": {
            "total_bessel_refinements": sum(int(c["bessel_refinements"]) for c in chain_results),
            "maximum_bessel_order": max(int(c["maximum_bessel_order"]) for c in chain_results),
            "maximum_acceptance_prefix_bits": max(int(c["maximum_acceptance_prefix_bits"]) for c in chain_results),
        },
        "authorization": {
            "production_sampler": "NOT_AUTHORIZED",
            "physical_Q2": "NOT_RUN",
            "reason": (
                "This is the fixed L=2 engineering profile. It does not validate warmup or larger-lattice "
                "mixing, does not include the separately labelled all-zero-start control, and is not a finite-size study."
            ),
        },
    }
    arrays = {
        "q": q,
        "winding": winding,
        "N_M": nm,
        "sum_I2": sum_i2,
        "state_hash_blake2b_128": hashes,
    }
    return aggregate, arrays


def run_profile(args: argparse.Namespace) -> dict[str, object]:
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    dynamics_path = Path(args.dynamics).resolve()
    started_at = utc_now()
    started_clock = time.perf_counter()
    test_result = self_test()
    geometry = make_geometry((2, 2, 2))
    chain_results: list[dict[str, object]] = []
    sample_sets: list[dict[str, np.ndarray]] = []

    for chain in range(8):
        runner = ChainRunner(
            chain=chain,
            geometry=geometry,
            warmup_sweeps=args.warmup,
            retained_sweeps=args.retained,
            checkpoint_every=args.checkpoint_every,
            invariant_mode=args.invariant_mode,
        )
        result, samples = runner.run()
        chain_results.append(result)
        sample_sets.append(samples)
        elapsed = time.perf_counter() - started_clock
        print(
            f"chain {chain}: attempts={result['attempted_microticks']} "
            f"accepted={result['outcomes'].get('ACCEPTED', 0)} elapsed={elapsed:.1f}s",
            flush=True,
        )

    aggregate, arrays = aggregate_results(chain_results, sample_sets)
    finished_at = utc_now()
    elapsed = time.perf_counter() - started_clock
    profile_is_frozen = args.warmup == 2000 and args.retained == 10000
    result_packet: dict[str, object] = {
        "schema": "td-cos-fh-run-receipt/1",
        "run_id": args.run_id,
        "run_class": "independent_execution_of_the_frozen_prose_profile",
        "kernel_id": "TD-COS-FH-001",
        "profile_conformance": (
            "FROZEN_PROSE_PROFILE_WITH_UNRECOVERED_MACHINE_AUTHORITY"
            if profile_is_frozen
            else "NONFROZEN_DEBUG_PROFILE"
        ),
        "source": {
            "title": "Toroidal Dynamics v0.1",
            "google_drive_id": "1ZMFcH3AV574iMI8qREeOcLS3NPb7rchNnyB1juHnYeM",
            "source_modified_time": "2026-09-06T16:43:01.559Z",
            "dynamics_prose_reconstruction_sha256": sha256_file(dynamics_path),
            "machine_readable_authority_available": False,
            "authority_gap": (
                "The Google Doc names DYNAMICS.json as authority, but its text is an unlinked relative-path "
                "reference and no Drive file with that name was retrievable on 2026-09-06."
            ),
        },
        "comparison_source": {
            "title": "Tiny-system validation v0.1",
            "google_drive_id": "1J43udMgUlfGXuMMdkCGw_Ef5vaZbYd9SasTzcQ1isEo",
            "role": "later comparison evidence; not used to change the frozen kernel",
        },
        "profile": {
            "shape": list(geometry.shape),
            "V": geometry.V,
            "E": geometry.E,
            "P": geometry.P,
            "microticks_per_sweep": geometry.B,
            "J": "1",
            "t": "1/2",
            "h6": "0",
            "ensemble": "Z000-fixed-reference",
            "chains": 8,
            "warmup_sweeps_per_chain": args.warmup,
            "retained_sweeps_per_chain": args.retained,
            "proposal_seeds": [64000 + i for i in range(8)],
            "acceptance_seeds": [74000 + i for i in range(8)],
            "first_retained_microtick": (args.warmup + 1) * geometry.B,
            "last_retained_microtick": (args.warmup + args.retained) * geometry.B,
        },
        "environment": {
            "python": sys.version,
            "python_implementation": platform.python_implementation(),
            "platform": platform.platform(),
            "numpy": np.__version__,
            "scipy": __import__("scipy").__version__,
        },
        "timing": {
            "started_at_utc": started_at,
            "finished_at_utc": finished_at,
            "elapsed_seconds": elapsed,
        },
        "contract_self_test": test_result,
        "aggregate": aggregate,
        "chains": chain_results,
        "evidence_boundary": (
            "This receipt is an engineering execution and reproducibility record. It is not production "
            "authorization, not a finite-size result, and not physical Q2 evidence."
        ),
    }

    samples_path = output_dir / "TD_COS_FH_001_L2_samples.npz"
    np.savez_compressed(samples_path, **arrays)
    result_packet["artifacts"] = {
        "samples_file": samples_path.name,
        "samples_sha256": sha256_file(samples_path),
    }
    results_path = output_dir / "TD_COS_FH_001_L2_run_results.json"
    results_path.write_text(json.dumps(result_packet, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"results={results_path}", flush=True)
    print(f"samples={samples_path}", flush=True)
    return result_packet


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dynamics", default="DYNAMICS_PROSE_RECONSTRUCTION.json")
    parser.add_argument("--output-dir", default="run_output")
    parser.add_argument("--run-id", default="TD-COS-FH-001-L2-REPRODUCTION-001")
    parser.add_argument("--warmup", type=int, default=2000)
    parser.add_argument("--retained", type=int, default=10000)
    parser.add_argument("--checkpoint-every", type=int, default=1000)
    parser.add_argument("--invariant-mode", choices=("accepted", "retained"), default="accepted")
    parser.add_argument("--self-test", action="store_true")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.self_test:
        print(json.dumps(self_test(), indent=2, sort_keys=True))
        return 0
    run_profile(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
