#!/usr/bin/env python3
"""Independent structural verification of a TD-COS-FH-001 run receipt."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def verify(results_path: Path, samples_path: Path, dynamics_path: Path) -> dict[str, object]:
    receipt = json.loads(results_path.read_text(encoding="utf-8"))
    samples = np.load(samples_path)
    checks: dict[str, bool] = {}

    profile = receipt["profile"]
    aggregate = receipt["aggregate"]
    checks["kernel_id"] = receipt["kernel_id"] == "TD-COS-FH-001"
    checks["fixed_shape"] = profile["shape"] == [2, 2, 2]
    checks["fixed_parameters"] = (
        profile["J"] == "1" and profile["t"] == "1/2" and profile["h6"] == "0"
    )
    checks["fixed_schedule"] = (
        profile["chains"] == 8
        and profile["warmup_sweeps_per_chain"] == 2000
        and profile["retained_sweeps_per_chain"] == 10000
        and profile["microticks_per_sweep"] == 71
        and profile["first_retained_microtick"] == 142071
        and profile["last_retained_microtick"] == 852000
    )
    checks["fixed_seeds"] = (
        profile["proposal_seeds"] == list(range(64000, 64008))
        and profile["acceptance_seeds"] == list(range(74000, 74008))
    )
    checks["attempt_accounting"] = (
        aggregate["attempted_microticks"] == 8 * 12000 * 71
        and sum(aggregate["outcomes"].values()) == aggregate["attempted_microticks"]
        and sum(v["attempted"] for v in aggregate["family_stats"].values())
        == aggregate["attempted_microticks"]
        and sum(v["accepted_nonidentity"] for v in aggregate["family_stats"].values())
        == aggregate["outcomes"]["ACCEPTED"]
    )
    checks["dynamics_reconstruction_hash"] = (
        receipt["source"]["dynamics_prose_reconstruction_sha256"] == sha256_file(dynamics_path)
    )
    checks["sample_file_hash"] = receipt["artifacts"]["samples_sha256"] == sha256_file(samples_path)

    q = samples["q"]
    winding = samples["winding"]
    nm = samples["N_M"]
    sum_i2 = samples["sum_I2"]
    state_hashes = samples["state_hash_blake2b_128"]
    checks["sample_shapes"] = (
        q.shape == (8, 10000)
        and winding.shape == (8, 10000, 3)
        and nm.shape == (8, 10000)
        and sum_i2.shape == (8, 10000)
        and state_hashes.shape == (8, 10000, 16)
    )
    counts = np.bincount(q.ravel(), minlength=8)
    checks["sector_counts_recomputed"] = all(
        int(counts[i]) == aggregate["coverage"]["sector_counts"][f"{i:03b}"] for i in range(8)
    )
    checks["retained_q_winding_parity"] = all(
        np.all((winding[:, :, axis] & 1) == ((q >> axis) & 1)) for axis in range(3)
    )
    checks["retained_activity_nonnegative"] = bool(np.all(nm >= 0) and np.all(sum_i2 >= 0))
    checks["chain_measurement_digests"] = all(
        hashlib.sha256(state_hashes[i].tobytes()).hexdigest()
        == receipt["chains"][i]["measurement_state_digest_sha256"]
        for i in range(8)
    )
    checks["online_invariant_receipt_clean"] = (
        aggregate["invariants"]["status"] == "PASS"
        and aggregate["invariants"]["failures"] == 0
        and all(chain["invariant_failures"] == 0 for chain in receipt["chains"])
    )
    checks["authorization_boundary_preserved"] = (
        aggregate["authorization"]["production_sampler"] == "NOT_AUTHORIZED"
        and aggregate["authorization"]["physical_Q2"] == "NOT_RUN"
    )
    checks["authority_gap_disclosed"] = (
        receipt["source"]["machine_readable_authority_available"] is False
        and "UNRECOVERED_MACHINE_AUTHORITY" in receipt["profile_conformance"]
    )

    failed = [name for name, passed in checks.items() if not passed]
    return {
        "schema": "td-cos-fh-receipt-verification/1",
        "status": "PASS" if not failed else "FAIL",
        "checks": checks,
        "failed_checks": failed,
        "results_sha256": sha256_file(results_path),
        "samples_sha256": sha256_file(samples_path),
        "dynamics_prose_reconstruction_sha256": sha256_file(dynamics_path),
        "scope": (
            "Structural receipt and retained-sample verification. Full I/M constraints were checked online "
            "by the sampler after every accepted update and at every retained measurement; the compact "
            "sample file does not contain complete I/M states for independent replay."
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", required=True)
    parser.add_argument("--samples", required=True)
    parser.add_argument("--dynamics", required=True)
    parser.add_argument("--output")
    args = parser.parse_args()
    result = verify(Path(args.results), Path(args.samples), Path(args.dynamics))
    rendered = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output:
        Path(args.output).write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
