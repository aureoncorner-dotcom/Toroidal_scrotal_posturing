# TD-COS-FH-001 — L=2 Frozen-Prose Execution Receipt v0.1

**Run:** `TD-COS-FH-001-L2-REPRODUCTION-001`  
**Disposition:** invariants PASS; eight-sector coverage PASS; mixing evidence favorable but incomplete; production **NOT AUTHORIZED**; physical Q2 **NOT RUN**.

## Bottom line

The declared eight-chain engineering profile completed all 6,816,000 microticks and retained 80,000 sweep-end measurements. The sampler recorded 1,107,368 accepted nonidentity updates, 4,939,515 rejected nonidentity proposals, and 769,117 identity updates. No invariant failure occurred.

Every chain visited all eight q sectors after warmup, both at event level and at retained-sweep resolution. Rank-normalized split R-hat stayed near one and bulk ESS was far above 1,000 on each axis. Those facts are evidence of movement and cross-chain agreement at L=2; they do not validate warmup, establish effective round trips, substitute for the separately labelled all-zero-start control, or authorize larger-lattice production.

## Provenance decision

The Google Doc named `DYNAMICS.json` as machine-readable authority, but the native document contains only the literal unlinked relative-path text and Drive contains no retrievable file with that name. Accordingly this execution is labeled **FROZEN_PROSE_PROFILE_WITH_UNRECOVERED_MACHINE_AUTHORITY**. It is not represented as a bit-exact execution of an unavailable file.

A later same-day document, `Tiny-system validation v0.1`, already records a run. This receipt is an independent prose-conformant execution, not a claim to be the first historical run and not a rewrite of either source document.

## Frozen profile executed

| Item | Executed value |
|---|---|
| Kernel | TD-COS-FH-001, cosine weights, fixed-reference Z000 |
| Couplings | J=1, t=1/2, h6=0 |
| Geometry | 2×2×2 periodic torus; V=8, E=24, P=24 |
| State | signed integer edge current I; binary face membrane M; three-bit q |
| Proposal weights | (8, 8, 24, 24, 1, 3, 3); B=71 microticks/sweep |
| Chains | 8, initialized once each in q=000 through 111 |
| Per chain | 2,000 warmup sweeps + 10,000 retained sweeps |
| Seeds | proposal 64000–64007; acceptance 74000–74007 |
| Observation clock | first retained microtick 142,071; last 852,000 |
| Acceptance | rational I_n(1) enclosures; 64-bit half-open U prefix |

## Invariant evidence

**Status: PASS.** 1,187,464 online checks; 0 failures.

| Declared invariant or consistency condition | Result |
|---|---|
| Integer-current conservation, div I=0 | PASS |
| I mod 2 + boundary(M) + Gamma(q)=0 | PASS |
| Every transverse cut gives the same signed W per axis | PASS |
| q_alpha = W_alpha mod 2 | PASS |
| Cached N_M equals the binary membrane occupancy | PASS |
| All 123 proposal descriptors preserve the constraints and have tested inverses | PASS |
| Rational Bessel comparison refinement | 0 refinements; K=16 and 64 bits resolved every decision |

The online checks ran after every accepted nonidentity update and again at retained measurements and checkpoints. The compact sample file independently rechecks retained q/W parity, counts, shapes, digests, and receipt accounting; it does not contain every full I/M state.

## Coverage

| q sector | Retained count | Probability | Preserved companion | Difference (percentage points) |
|---:|---:|---:|---:|---:|
| 000 | 10,549 | 13.1862% | 12.9262% | +0.2600 |
| 001 | 10,195 | 12.7438% | 12.6500% | +0.0938 |
| 010 | 10,110 | 12.6375% | 12.6312% | +0.0062 |
| 011 | 9,662 | 12.0775% | 12.3462% | -0.2688 |
| 100 | 10,138 | 12.6725% | 12.5688% | +0.1037 |
| 101 | 9,882 | 12.3525% | 12.2037% | +0.1488 |
| 110 | 9,868 | 12.3350% | 12.5100% | -0.1750 |
| 111 | 9,596 | 11.9950% | 12.1638% | -0.1687 |

Every chain covered all eight sectors at event level and at retained sweeps. Positive and negative signed winding occurred on every axis. Observed winding ranges were x=[-6,6], y=[-6,6], z=[-5,6], and max |I_link| was 5; these are observations, not cutoffs.

## Mixing evidence

| Observable | Mean / odd fraction | Classical split R-hat | Rank-normalized split R-hat | Rank bulk ESS | Raw 0→1→0 trips |
|---|---:|---:|---:|---:|---:|
| 1[q_x=1] | 0.491687 | 1.0000772 | 1.0000772 | 29471 | 16,682 |
| 1[q_y=1] | 0.490450 | 0.9999984 | 0.9999984 | 30620 | 16,959 |
| 1[q_z=1] | 0.493550 | 1.0001487 | 1.0001487 | 29468 | 16,835 |
| N_M | — | 1.0002475 | 1.0002471 | 29432 | — |

Largest classical split R-hat: **1.0002475**. Retained-sweep q residence runs had median 1 sweep, 95th percentile 4, and maximum 12 sweeps.

The numerical pieces of the inherited screen are favorable: rank-normalized R-hat is below 1.01 and rank bulk ESS exceeds 1,000 on every axis. The full mixing gate is **not established** because the counted trips are raw, not decorrelated/effective, and the separately labelled all-zero-start control was not part of this fixed profile.

### Retained-sweep q transition counts

Rows are the current sector; columns are the next retained-sweep sector.

| from \ to | 000 | 001 | 010 | 011 | 100 | 101 | 110 | 111 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 000 | 4,121 | 1,462 | 1,539 | 554 | 1,512 | 572 | 564 | 225 |
| 001 | 1,512 | 3,927 | 544 | 1,440 | 559 | 1,457 | 212 | 541 |
| 010 | 1,543 | 572 | 3,818 | 1,381 | 577 | 226 | 1,420 | 573 |
| 011 | 568 | 1,476 | 1,426 | 3,585 | 222 | 516 | 502 | 1,367 |
| 100 | 1,423 | 585 | 567 | 212 | 3,810 | 1,437 | 1,517 | 586 |
| 101 | 568 | 1,407 | 227 | 555 | 1,431 | 3,742 | 563 | 1,389 |
| 110 | 591 | 207 | 1,460 | 550 | 1,476 | 570 | 3,677 | 1,336 |
| 111 | 223 | 558 | 529 | 1,383 | 551 | 1,362 | 1,411 | 3,576 |

## Proposal and acceptance coverage

| Family | Attempts | Accepted | Acceptance fraction |
|---|---:|---:|---:|
| IDENTITY | 769,117 | 0 | — |
| CUBE | 767,819 | 301,016 | 39.204% |
| COUPLED_PLAQUETTE | 2,304,368 | 516,828 | 22.428% |
| EVEN_PLAQUETTE | 2,303,599 | 80,602 | 3.499% |
| CLOSED_SHEET | 96,198 | 47,525 | 49.403% |
| EVEN_REFERENCE_CYCLE | 287,393 | 40,256 | 14.007% |
| UNIT_SECTOR_CYCLE | 287,506 | 121,141 | 42.135% |

## Comparison with the later Drive companion

The proposal accounting agrees exactly: both records contain **6,046,883 nonidentity proposals**. The trajectories do not agree bit-for-bit: this run accepted 1,107,368, versus 1,108,720 in the companion (-1,352); raw round-trip differences are x=-93, y=+9, z=+69. The largest sector-probability point difference is 0.2688 percentage points.

That pattern is consistent with the same proposal schedule but a different unrecovered low-level convention such as cell indexing/orientation or acceptance implementation. It is not enough to identify which convention differs. Because the named machine-readable authority is absent, this receipt preserves the mismatch instead of harmonizing it away.

## Decision

- Accept this packet as an executable, reproducible L=2 **pre-production engineering run** of the frozen prose profile.
- Accept the declared invariant and eight-sector coverage evidence for this implementation.
- Treat the mixing results as favorable diagnostics, not production certification.
- Do not infer confinement, deconfinement, equilibrium at larger L, a physical timescale, or physical Q2.
- Before any production authorization, recover or formally replace the missing authoritative `DYNAMICS.json`, resolve the deterministic mismatch, run the separately labelled all-zero-start control, establish effective—not merely raw—round trips, and execute the larger-lattice validation gates under a new frozen profile.

## Verification

Independent receipt verification: **PASS** (16/16 checks passed).

CC0 1.0 Universal. No production authorization. No physical Q2 result.
