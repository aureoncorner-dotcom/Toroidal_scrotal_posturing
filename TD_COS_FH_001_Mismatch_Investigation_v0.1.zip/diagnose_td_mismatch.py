#!/usr/bin/env python3
"""Bounded TD-COS-FH-001 evidence recovery; no production or physical Q2 run.

Reads an unmodified reproduction packet. Replays eight chains only through
microtick 142071. Saves the first 512 events per chain with full before/after
states, acceptance evidence and RNG digests, plus restartable checkpoints.
"""
import argparse
import gzip
import hashlib
import importlib
import json
import platform
import sys
from collections import Counter
from pathlib import Path


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--trace-only', action='store_true', help='regenerate only the 512-event sidecars')
    args = ap.parse_args()
    source = args.source.resolve()
    out = args.out.resolve()
    if source == out or source in out.parents:
        ap.error('output must be separate from the preserved source packet')
    out.mkdir(parents=True, exist_ok=True)
    sys.path.insert(0, str(source))
    s = importlib.import_module('td_cos_fh_001_sampler')
    v = importlib.import_module('verify_td_receipt')
    import numpy as np

    manifest = json.loads((source / 'MANIFEST.json').read_text())
    hashes = []
    for entry in manifest['files']:
        b = (source / entry['path']).read_bytes()
        hashes.append({'path': entry['path'], 'sha256': hashlib.sha256(b).hexdigest(),
                       'pass': len(b) == entry['bytes'] and hashlib.sha256(b).hexdigest() == entry['sha256']})
    if not all(x['pass'] for x in hashes):
        raise RuntimeError('source manifest mismatch; no replay performed')
    structural = v.verify(source/'TD_COS_FH_001_L2_run_results.json',
                          source/'TD_COS_FH_001_L2_samples.npz',
                          source/'DYNAMICS_PROSE_RECONSTRUCTION.json')
    receipt = json.loads((source/'TD_COS_FH_001_L2_run_results.json').read_text())
    samples = np.load(source/'TD_COS_FH_001_L2_samples.npz', allow_pickle=False)

    def state(r):
        return {'I': r.state.I.copy(), 'M': list(r.state.M), 'q_integer': r.state.q,
                'q_printed_zyx': f'{r.state.q:03b}',
                'q_xyz': [(r.state.q >> a) & 1 for a in range(3)],
                'N_M': r.state.nm, 'W_xyz': list(s.signed_winding(r.state,r.g)),
                'sum_I2': sum(x*x for x in r.state.I),
                'state_hash_blake2b_128': s.state_hash(r.state).hex()}

    class Tracer(s.ChainRunner):
        def __init__(self, chain):
            super().__init__(chain, s.make_geometry(), 2000, 10000, 1000, 'accepted')
            self.capture = False
            self.captured = {}
            original_decide = self.oracle.decide
            def decide(signature, rng):
                result = original_decide(signature, rng)
                if self.capture:
                    accepted, prefix, bits, order = result
                    low, high = self.oracle.ratio_bounds(signature,order)
                    self.captured['acceptance'] = {
                        'signature': signature, 'accepted': accepted,
                        'prefix': str(prefix), 'prefix_bits': bits, 'series_order': order,
                        'ratio_lower': str(low), 'ratio_upper': str(high)}
                return result
            self.oracle.decide = decide

        def choose_family(self):
            f = super().choose_family()
            if self.capture:
                self.captured['family'] = s.FAMILY_NAMES[f]
            return f

        def proposal(self, family):
            p = super().proposal(family)
            if self.capture:
                a,b,sign,changes,toggles,qxor = p
                self.captured['proposal'] = {'a': a,'b': b,'sign': sign,
                    'current_changes': changes,'membrane_toggles': toggles,'q_xor': qxor}
            return p

    audit = {'schema':'td-mismatch-bounded-diagnostic/1',
        'scope':'Eight original reproduction prefixes; companion executable and event stream unavailable',
        'source_manifest_checks':hashes, 'structural_verification':structural,
        'contract_self_test':s.self_test(), 'python':sys.version,
        'platform':platform.platform(), 'numpy':np.__version__,
        'chains':[], 'trace_events_per_chain':512,
        'microticks_per_chain':142071, 'total_replayed_microticks':8*142071,
        'companion_first_divergence':None, 'root_cause':'UNRESOLVED',
        'production_authorization':'NOT_AUTHORIZED','physical_Q2':'NOT_RUN'}
    trace_lines = []
    for chain in range(8):
        r = Tracer(chain)
        checkpoints = []
        def checkpoint(tick):
            checkpoints.append({'chain':chain,'microtick':tick,'state':state(r),
                'proposal_rng_state':r.proposal_rng.getstate(),
                'acceptance_rng_state':r.acceptance_rng.getstate(),
                'proposal_rng_sha256':s.rng_state_digest(r.proposal_rng),
                'acceptance_rng_sha256':s.rng_state_digest(r.acceptance_rng)})
        checkpoint(0)
        prefix_checks = Counter()
        first_no_draw = None
        for tick in range(1,513 if args.trace_only else 142072):
            r.capture = tick <= 512
            if r.capture:
                r.captured = {'chain':chain,'microtick':tick,'before':state(r),
                    'proposal_rng_before':s.rng_state_digest(r.proposal_rng),
                    'acceptance_rng_before':s.rng_state_digest(r.acceptance_rng)}
            r.microtick(tick)
            if r.capture:
                e = r.captured
                e.update({'after':state(r),
                    'proposal_rng_after':s.rng_state_digest(r.proposal_rng),
                    'acceptance_rng_after':s.rng_state_digest(r.acceptance_rng)})
                if e['family'] == 'IDENTITY':
                    e['outcome'] = 'IDENTITY'
                    assert e['before'] == e['after']
                    assert e['acceptance_rng_before'] == e['acceptance_rng_after']
                else:
                    a = e['acceptance']
                    e['outcome'] = 'ACCEPTED' if a['accepted'] else 'REJECTED'
                    # Independent global-histogram signature on the proposed state.
                    p = e['proposal']
                    trial = e['before']['I'].copy()
                    for edge,delta in p['current_changes']:
                        trial[edge] += delta
                    powers = Counter(abs(x) for x in trial)
                    powers.subtract(Counter(abs(x) for x in e['before']['I']))
                    delta_nm = sum(1-2*e['before']['M'][f] for f in p['membrane_toggles'])
                    global_sig = (delta_nm,tuple(sorted((n,c) for n,c in powers.items() if c)))
                    assert global_sig == a['signature']
                    # Re-evaluate at K=32: no additional random draws.
                    low,high = r.oracle.ratio_bounds(global_sig,32)
                    prefix,bits = int(a['prefix']),a['prefix_bits']
                    if bits == 0:
                        assert low >= 1
                        assert e['acceptance_rng_before'] == e['acceptance_rng_after']
                        if first_no_draw is None:
                            first_no_draw = {'microtick':tick,'family':e['family'],'signature':global_sig}
                    elif a['accepted']:
                        assert s.Fraction(prefix+1,1<<bits) <= min(1,low)
                    else:
                        assert s.Fraction(prefix,1<<bits) >= min(1,high)
                    prefix_checks['global_signature_and_K32_decision'] += 1
                    if not a['accepted']:
                        assert e['before'] == e['after']
                s.validate_state(r.state,r.g)
                prefix_checks['full_state_invariant'] += 1
                trace_lines.append(json.dumps(e,sort_keys=True,separators=(',',':'))+'\n')
            if tick in (512,142000,142071):
                checkpoint(tick)
        if args.trace_only:
            continue
        historical = receipt['chains'][chain]['checkpoints'][0]
        warm = checkpoints[-2]
        current = checkpoints[-1]['state']
        checks = {
            'warmup_state_hash':warm['state']['state_hash_blake2b_128']==historical['state_hash_blake2b_128'],
            'warmup_proposal_rng':warm['proposal_rng_sha256']==historical['proposal_rng_state_sha256'],
            'warmup_acceptance_rng':warm['acceptance_rng_sha256']==historical['acceptance_rng_state_sha256'],
            'first_retained_state_hash':current['state_hash_blake2b_128']==bytes(samples['state_hash_blake2b_128'][chain,0]).hex(),
            'first_retained_q':current['q_integer']==int(samples['q'][chain,0]),
            'first_retained_W':current['W_xyz']==samples['winding'][chain,0].tolist(),
            'first_retained_N_M':current['N_M']==int(samples['N_M'][chain,0]),
            'first_retained_sum_I2':current['sum_I2']==int(samples['sum_I2'][chain,0])}
        result = {'chain':chain,'checks':checks,'pass':all(checks.values()),
            'prefix_checks':dict(prefix_checks),'first_proven_acceptance_without_draw':first_no_draw,
            'outcomes_through_first_retained':dict(r.outcomes),
            'full_online_invariant_checks':r.invariant_checks}
        audit['chains'].append(result)
        dump(out/f'chain_{chain}_restartable_checkpoints.json',checkpoints)
        print(json.dumps(result),flush=True)
    (out/'reproduction_prefix_events.jsonl').write_text(''.join(trace_lines),encoding='utf-8')
    with (out/'reproduction_prefix_events.jsonl').open() as events:
        assert sum(1 for _ in events) == 4096, 'trace output incomplete'
    if args.trace_only:
        print('Recovered and verified 4096 trace rows',flush=True)
        return 0
    audit['reproduction_prefix_replay_status'] = 'PASS' if all(x['pass'] for x in audit['chains']) else 'FAIL'
    dump(out/'BOUNDED_DIAGNOSTICS.json',audit)
    return 0 if audit['reproduction_prefix_replay_status']=='PASS' else 1

if __name__=='__main__':
    raise SystemExit(main())
