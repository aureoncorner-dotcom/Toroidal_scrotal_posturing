# TD-COS-FH-001 mismatch investigation packet

Read `TD_COS_FH_001_Mismatch_Investigation_v0.1.md` for findings and limits.

The cross-run mismatch is unresolved because the companion executable and
event files were not recovered. The contained source sampler is the preserved
reproduction implementation, not a recovered companion implementation.

## Contents

- `preserved_reproduction/`: original recovered packet files, unchanged.
- `sources/`: retrieved companion and dynamics prose snapshots and retrieval record.
- `diagnostics/BOUNDED_DIAGNOSTICS.json`: manifest, structural and bounded replay checks.
- `diagnostics/reproduction_prefix_events.jsonl`: first 512 events of each of eight chains.
- `diagnostics/chain_*_restartable_checkpoints.json`: complete state and RNG snapshots at 0, 512, 142000 and 142071.
- `diagnose_td_mismatch.py`: bounded regeneration using the original source sampler, with an additive observer.
- `compare_td_traces.py`: first differing event per chain in aligned canonical traces.
- `DIAGNOSTIC_MANIFEST.json`: hashes of all included files except itself.

## Reproduce

Requires Python 3.12, NumPy and SciPy. Exact versions used are in the diagnostic JSON.
Run from the extracted packet directory. Output must be separate from preserved sources.

```bash
python3 diagnose_td_mismatch.py --source preserved_reproduction --out new_diagnostics
```

For just the detailed prefix trace (4,096 microticks total):

```bash
python3 diagnose_td_mismatch.py --source preserved_reproduction --out new_trace --trace-only
```

When the companion's event format and byte encodings are recovered, convert
its trace into the same canonical schema, preserving source bytes and the
adapter separately. Compare a contiguous prefix beginning at microtick 1 in
chain order, with x/y/z cells and q bits explicitly normalized:

```bash
python3 compare_td_traces.py diagnostics/reproduction_prefix_events.jsonl companion_canonical_events.jsonl --output first_divergence.json
```

`companion_canonical_events.jsonl` is a required future input, not a file
included in this packet. The comparator has not compared the actual companion.
Its synthetic mutation checks test the comparator only.

Checkpoint RNG states are JSON lists: convert them recursively back to tuples
before `random.Random.setstate`. State vectors are explicit signed I values,
binary M values, integer q and cached N_M; their hashes use the preserved sampler.
Checkpoint serialization was round-trip checked, including all state/RNG digests.

Both historical records and the −1,352 difference are retained. No target,
coupling, proposal, acceptance rule, schedule or historical count was patched.
Production remains NOT_AUTHORIZED; physical Q2 remains NOT_RUN.

CC0 1.0 Universal.
