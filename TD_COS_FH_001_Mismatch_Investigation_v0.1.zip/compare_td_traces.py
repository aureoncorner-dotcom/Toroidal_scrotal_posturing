#!/usr/bin/env python3
"""Compare canonical TD event JSONL streams, reporting first divergence per chain.

Both streams must use the diagnostic tracer's schema, normalized to the same
cell order, q bit order and hash/RNG encodings. A missing field is an evidence
gap, not equality. This comparator does not infer events from aggregate counts.
"""
import argparse
import gzip
import json
from itertools import zip_longest
from pathlib import Path

FIELDS = [
    ('before', 'PRESTATE_DIVERGENCE'),
    ('proposal_rng_before', 'PROPOSAL_RNG_DIVERGENCE'),
    ('acceptance_rng_before', 'ACCEPTANCE_RNG_DIVERGENCE'),
    ('family', 'PROPOSAL_DIVERGENCE'),
    ('proposal', 'PROPOSAL_DIVERGENCE'),
    ('acceptance', 'ACCEPTANCE_EVIDENCE_DIVERGENCE'),
    ('outcome', 'DECISION_DIVERGENCE'),
    ('after', 'POSTSTATE_DIVERGENCE'),
    ('proposal_rng_after', 'PROPOSAL_RNG_DIVERGENCE'),
    ('acceptance_rng_after', 'ACCEPTANCE_RNG_DIVERGENCE'),
]

def records(path):
    opener = gzip.open if str(path).endswith('.gz') else open
    with opener(path,'rt',encoding='utf-8') as f:
        for line in f:
            if line.strip():
                yield json.loads(line)

def compare(left, right):
    compared = 0
    failures = {}
    last = {}
    for a,b in zip_longest(left,right):
        if a is None or b is None:
            return {'status':'INCOMPLETE_EVIDENCE','matched_or_compared_rows':compared,
                    'first_divergence_per_chain':list(failures.values()),'reason':'unequal stream lengths'}
        address = (a.get('chain'),a.get('microtick'))
        if address != (b.get('chain'),b.get('microtick')) or None in address:
            return {'status':'INCOMPLETE_EVIDENCE','reason':'unaligned event addresses',
                    'left_address':address,'right_address':(b.get('chain'),b.get('microtick'))}
        chain,tick = address
        if tick != last.get(chain,0)+1:
            return {'status':'INCOMPLETE_EVIDENCE','reason':'prefix must start at 1 and be contiguous per chain'}
        last[chain] = tick
        compared += 1
        differences=[]
        for field,category in FIELDS:
            if field=='acceptance' and a.get('family')==b.get('family')=='IDENTITY':
                continue
            if field not in a or field not in b:
                differences.append({'field':field,'category':'MISSING_EVIDENCE'})
            elif a[field]!=b[field]:
                differences.append({'field':field,'category':category,'left':a[field],'right':b[field]})
        if differences and chain not in failures:
            failures[chain]={'chain':chain,'microtick':tick,'differences':differences}
    if compared == 0:
        return {'status':'INCOMPLETE_EVIDENCE','reason':'empty streams'}
    return {'status':'DIVERGENCE' if failures else 'MATCH_ON_SUPPLIED_PREFIX',
            'compared_rows':compared,'last_microtick_per_chain':last,
            'first_divergence_per_chain':list(failures.values()),
            'scope':'Only supplied canonical contiguous prefixes; no full-run equivalence claim'}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('left',type=Path)
    ap.add_argument('right',type=Path)
    ap.add_argument('--output',type=Path)
    args=ap.parse_args()
    result=compare(records(args.left),records(args.right))
    text=json.dumps(result,indent=2,sort_keys=True)+'\n'
    if args.output:
        args.output.write_text(text)
    print(text,end='')
    return 0 if result['status']=='MATCH_ON_SUPPLIED_PREFIX' else 1

if __name__=='__main__':
    raise SystemExit(main())
